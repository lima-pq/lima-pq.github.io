/* We time some subroutines here,
 * For XOR and FFT is only a crude timing mainly for development purposes
 *
 * For encryption timings we use the seed lengths recommended in the
 * main document, and pull our random values from /dev/urandom
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "../cpucycles-20060326/cpucycles.h"

#include "xof.h"
#include "fft.h"
#include "LimaAPI.h"

#define count 10000000
#define count_FFT 500
#define count_enc 5000


void Time_XOF()
{
    printf("Timing XOF\n");

    XOF_t xof;

    double start,time;

    uint8_t seed[32];
    int i, a,ss=0;
    for (i = 0; i<32; i++) { seed[i] = i; }
    // Some fake use of a[i] put in to avoid optimizing out.

    start = clock();
    for (int i = 0; i<count; i++)
    {
        InitXOF(&xof,seed,32,1);
    }
    time = (clock() - start)/count;
    printf("XOF Set Up Time : %f\n", time);

    start = clock();
    for (int i = 0; i<count; i++)
    {
        a= get_random_field_element(&xof, &mod18433); 
        ss=ss+to_int(&mod18433,a);
    }
    time = (clock() - start)/count;
    printf("Random F_{18433} Time : %f\n", time);
    

    start = clock();
    for (int i = 0; i<count; i++)
    {
        a = get_random_field_element(&xof, &mod44802049);
        ss=ss+to_int(&mod44802049,a);
    }
    time = (clock() - start)/count;
    printf("Random F_{44802049} Time : %f\n", time);

    start = clock();
    for (int i = 0; i<count; i++)
    {
        a = generate_gaussian_noise(&xof); 
        ss=ss+a;
    }
    time = (clock() - start)/count;
    printf("Random Gaussian Time : %f\n", time);

    printf("Fake ss = %d\n",ss);
}




void Time_FFT_Sub(lima_params_t* params)
{
    fflush(stdout);

    int a[LIMA_MAX_N];
    int i, v, N = params->N;

    double start, time;

    // Compute FFT of all one vector repeatedly
    for (i = 0; i<N; i++)
    {
        a[i] = to_mod_q(params->ctx, 1);
    }
    start = clock();
    for (int i = 0; i<count_FFT; i++)
    {
        fft(params, a, a);
    }
    time = (clock() - start) / count_FFT;
    printf("FFT Time : %f\n", time);
    
    // Unwind that computation
    start = clock();
    for (int i = 0; i<count_FFT; i++)
    {
        fft_inv(params, a, a);
    }
    time = (clock() - start) / count_FFT;
    printf("iFFT Time : %f\n", time);

    /* As double check of arithmetic we check the answer*/
    for (int i=0; i<N; i++)
      { v=to_int(params->ctx,a[i]);
        if (v!=1) { abort(); }
      }
}



void Time_FFT()
{
    printf("lima_2p_512\n");
    Time_FFT_Sub(&lima_2p_512);
    printf("lima_2p_1024\n");
    Time_FFT_Sub(&lima_2p_1024);
    printf("lima_2p_2048\n");
    Time_FFT_Sub(&lima_2p_2048);
    printf("lima_sp_1018\n");
    Time_FFT_Sub(&lima_sp_1018);
    printf("lima_sp_1306\n");
    Time_FFT_Sub(&lima_sp_1306);
    printf("lima_sp_1822\n");
    Time_FFT_Sub(&lima_sp_1822);
    printf("lima_sp_2062\n");
    Time_FFT_Sub(&lima_sp_2062);
}



void get_randombytes(uint8_t *seed,unsigned long long slen,FILE *fp)
{
  fread(seed,1,slen,fp);
}




void Time_Encryption(int sklen,int pklen)
{
  uint8_t pks[20000],sks[30000],cts[17000];
  uint8_t seed[48],mess[32],messo[32],seed2[32],seed3[80],key[32],keyo[32];
  byte_length clen,mlen,klen;
  unsigned long long cycle_cnt;

  printf("\n------------------------------------------------\n");
  printf("pk_sz = %i,  sk_sz = %i\n",pklen,sklen);

  double start,time;

  FILE *fp = fopen("/dev/urandom", "r");

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
     { get_randombytes(seed,48,fp);
       if (Key_Generation(pks,pklen,sks,sklen,seed,48)) { abort(); }
     }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("Key Generation:");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  for (int i=0; i<32; i++) { mess[i]=255-i; }
  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
     { get_randombytes(seed,48,fp);
       if (Enc_CPA(cts,&clen,mess,32,seed,48,pks)) { abort(); }
     }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CPA Encryption");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { if (Dec_CPA(messo,&mlen,cts,sks)) { abort(); } }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CPA Decryption");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
     { get_randombytes(seed2,32,fp);
       if (Enc_CCA(cts,&clen,mess,32,seed2,pks)) { abort(); }
     }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CCA Encryption");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { if (Dec_CCA(messo,&mlen,cts,sks)) { abort(); } }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CCA Decryption");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { get_randombytes(seed3,80,fp);
      if (Encap_CPA(cts,&clen,key,32,seed3,80,pks)) { abort(); }
    }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CPA Encapsulation");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { if (Decap_CPA(keyo,&klen,cts,sks)) { abort(); } }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CPA Decapsulation");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { get_randombytes(seed,48,fp);
      if (Encap_CCA(cts,&clen,key,32,seed,48,pks)) { abort(); }
    }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CCA Encapsulation");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  start=clock();                   cycle_cnt=cpucycles();
  for (int i=0; i<count_enc; i++)
    { if (Decap_CCA(keyo,32,cts,sks)) { abort(); } }
  time=(clock()-start)/count_enc;  cycle_cnt=(cpucycles()-cycle_cnt)/count_enc;
  time/=CLOCKS_PER_SEC/1000.0;
  printf("CCA Decapsulation");
  printf("  Time : %f ms\t",time);
  printf("  Cycle Count : %llu\n",cycle_cnt);

  fclose(fp);
}




void Time_Enc()
{
  int sk_sz[7]={3073, 6145, 12289,9163,15673,21865,24745};
  int pk_sz[7]={2049, 4097, 8193,6109,10449,14577,16497};

  for (int i=0; i<7; i++)
     { Time_Encryption(sk_sz[i],pk_sz[i]); }


}




int main(int argc,char* argv[])
{ 
  InitLima();
  printf("A simple timing program for various routines\n");
  int done=0;
  if (argc == 1 || strcmp(argv[1], "All") == 0 || strcmp(argv[1], "XOF") == 0)
    { Time_XOF(); done=1; }
  if (argc == 1 || strcmp(argv[1], "All") == 0 || strcmp(argv[1], "FFT") == 0)
    { Time_FFT(); done = 1; }
  if (argc == 1 || strcmp(argv[1], "All") == 0 || strcmp(argv[1], "ENC") == 0)
    { Time_Enc(); done = 1; }
  if (!done)
    { printf("Either use with no arguments or arguments \n");
      printf("\t All\n");
      printf("\t XOF (Not proper timing, just for testing purposes)\n");
      printf("\t FFT (Not proper timing, just for testing purposes)\n");
      printf("\t ENC\n");
    }

  fprintf(stderr,"Finished\n");
  return 0;
}
